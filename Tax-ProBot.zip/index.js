//development By Sanad
const express = require("express");
const app = express();

app.listen(() => console.log("Made By Sanad"));
//development By Sanad

const Discord = require('discord.js');
const client = new Discord.Client();

client.on('ready', () => {
console.log(`[NAME] ${client.user.tag}`)
console.log(`[ID] ${client.user.id}`)
console.log(`[GUILDS] ${client.guilds.cache.size}`)
console.log(`[PING] ${client.ws.ping}`)
client.user.setStatus("dnd") 
  
  //let ac = ["listening", "watching", "playing", "streaming","default"];

  //let ac2 = ["online", "idle", "invisible", "dnd","default"]; // ذي حالات يلي تقدر تحطها

  // حاله البوت 
  
function msg() { 
 let status = [`Tax Probot`]; // كتابه الحاله
 let S = Math.floor(Math.random() * status.length);
 client.user.setActivity(status[S],{ type : 'PLAYING'})
};
setInterval(msg,7000)
})
 
client.on("message", async message => {  

   
const prefix = "+";//برفكس حقك
const devs = "766659211345395762";//اي دي حقك
  let args = message.content
    .split(" ")
    .slice(1)
    .join(" "); if (message.author.bot) return;
  if (!message.guild) return;
  if (!message.content.startsWith(prefix)) return;
  if (message.content.toLowerCase().startsWith(prefix + "help".toLowerCase())) { 
    let help = new Discord.MessageEmbed()
      .setColor("#cea00d")
      // رابط تحميل الايموجي الموجود بالبوت https://cdn.discordapp.com/emojis/996483636373233675.webp?size=96&quality=lossless
      
      .setDescription(`** Probot Tax 💳
 
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>           
・ ${prefix}tax 
**لمعرفه ضريبه برو بوت**
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>
・ ${prefix}wtax
**لمعرفه ضريبه الوسيط**
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>
・ ${prefix}ping
**لمعرفة سرعة استجابة البوت**
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>
 👨🏽‍💻Developer  Sanad**`);  //development By Sanad
    
    message.channel.send(help);
  }
  if (message.content.toLowerCase().startsWith(prefix + "wtax".toLowerCase())) { 
    let args2 = parseInt(args)
    let tax = Math.floor(args2 * (20) / (19) + (1))
    let tax2 = Math.floor(args2 * (20) / (19) + (1)-(args2))
    let tax3 = Math.floor(tax2 * (20) / (19) + (1))
    let tax4 = Math.floor(tax2 + tax3 + args2)
    let errorembed3 = new Discord.MessageEmbed()
.setTitle(`خطأ ❌`)
.setColor("#cea00d")
    .setDescription(`**يجب إختيار رقم مثل
-tax 1000**`)
            // رابط تحميل الايموجي الموجود بالبوت https://cdn.discordapp.com/emojis/996483636373233675.webp?size=96&quality=lossless
//اذا تبي عدل الفوتر
    .setFooter(`Sanad Tax`);
    if (!args2) return message.channel.send(errorembed3);
    let errorembed2 = new Discord.MessageEmbed()
    .setTitle(`**❌ خطأ**`)
    .setColor("#cea00d")
    .setDescription(`**يجب إختيار رقم مثل
-tax 1000**`)
      //اذا تبي عدل الفوتر
    .setFooter(`Sanad Tax`);
    if (isNaN(args2)) return message.channel.send(errorembed2);
    let errorembed = new Discord.MessageEmbed()
    .setTitle(`**❌ خطأ**`)
    .setColor("#cea00d")
    .setDescription(`**يجب إختيار رقم مثل
-tax 1000**`)
    .setFooter(`${client.user.username}`);
    if (args2 < 1) return message.channel.send(errorembed);
    let embed3 = new Discord.MessageEmbed()
    .setTitle(`**يجب إختيار رقم مثل
-tax 1000**`)
    .setColor("#cea00d")
    .setDescription(`1`)
           //development By Sanad
//اذا تبي عدل الفوتر
    .setFooter(`Sanad Tax`); 
    if (args2 == 1) return message.channel.send(embed3);
    let embed = new Discord.MessageEmbed()
    .setTitle(`** <:pp506:996523401818685520> المبلغ المراد دفعه **`)
    .setColor("#cea00d")
    .setDescription(`**ضريبه الوسيط**  **${tax2}**
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>
                      **ضريبة التحويل**  **${tax3}**
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>
                      **المبلغ المطلوب تحويله**  **${tax4}**
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>`)
    .setFooter(`Sanad Tax`); //اذا تبي عدل الفوتر
    message.channel.send(embed);
  }

//development By Sanad

  if (message.content.toLowerCase().startsWith(prefix + "tax".toLowerCase())) { 
    let args2 = parseInt(args)
    let tax = Math.floor(args2 * (20) / (19) + (1))
    let errorembed3 = new Discord.MessageEmbed()
    .setTitle(`**❌ خطأ**`)
    .setColor("#cea00d")
    .setDescription(`**يجب إختيار رقم مثل
-tax 1000**`) //اذا تبي عدل الفوتر
    .setFooter(`Sanad Tax`);
    if (!args2) return message.channel.send(errorembed3);
    let errorembed2 = new Discord.MessageEmbed()
    .setTitle(`**❌ خطأ**`)
    .setColor("#cea00d")
    .setDescription(`**يجب إختيار رقم مثل
-tax 1000**`)
    .setFooter(`Sanad Tax`); 
//اذا تبي عدل افوتر
          // رابط تحميل الايموجي الموجود بالبوت https://cdn.discordapp.com/emojis/996483636373233675.webp?size=96&quality=lossless
    if (isNaN(args2)) return message.channel.send(errorembed2);
    let errorembed = new Discord.MessageEmbed()
    .setTitle(`**EROR❌**`)
    .setColor("#cea00d")
    .setDescription(`**يجب إختيار رقم مثل
-tax 1000**`)
    .setFooter(`Sanad Tax`); // اذا تبي عدل الفوتر
    if (args2 < 1) return message.channel.send(errorembed);
    let embed3 = new Discord.MessageEmbed()
    .setTitle(`** <:pp506:996523401818685520> المبلغ المراد دفعه **`)
    .setColor("#cea00d")
    .setDescription(`1`)
    .setFooter(`Sanad Tax`); 
    //اذا تبي عدل الفوتر
          ///development By Sanad
    if (args2 == 1) return message.channel.send(embed3);
    let embed = new Discord.MessageEmbed()
    .setTitle(`** <:pp506:996523401818685520> المبلغ المراد دفعه **`)
    .setDescription(`<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>
${tax}
<:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675><:pp711:996483636373233675>`)
    .setColor("#cea00d")
    .setFooter(`Sanad Tax`); //اذا تبي عدل الفوتر
    message.channel.send(embed);
  }

  //development By Sanad
  
      // رابط تحميل الايموجي الموجود بالبوت https://cdn.discordapp.com/emojis/996483636373233675.webp?size=96&quality=lossless
 

let ac = ["listening", "watching", "playing", "streaming","default"];
let ac2 = ["online", "idle", "invisible", "dnd","default"]; // ذي حالات يلي تقدر تحطها

 let args0 = message.content.split(" ");
  if (args0[0] === ('settings')) {
   if (!devs.includes(message.author.id)) return;
    if (args0[1] === 'setname') {
      if (!args0[2]) return message.channel.send('**:x: Please input a new name.**');
      await client.user.setUsername(args0.slice(2).join(" "));
 let changedname = new Discord.MessageEmbed()
  .setTimestamp().setColor("YELLOW").setAuthor(message.author.username, message.author.displayAvatarURL()).setFooter(client.user.username,client.user.displayAvatarURL()).setThumbnail(message.guild.iconURL())
  .setDescription(`**✅ Done , The bot name changed to : ${args0.slice(2).join(" ")}**`)
  message.channel.send(changedname)
       message.react('✅');
    } else if (args0[1] === 'setavatar') {
      if (!args0[2]) return message.channel.send('**:x: Please input an avatar URL.**');
      await client.user.setAvatar(args0.slice(2).join(" "));
 let changedavatar = new Discord.MessageEmbed()
  .setTimestamp().setImage(args0.slice(2).join(" ")).setColor("YELLOW").setAuthor(message.author.username, message.author.displayAvatarURL()).setFooter(client.user.username,client.user.displayAvatarURL()).setThumbnail(message.guild.iconURL())
  .setDescription(`**✅ The bot avatar was changed to :**`)
  message.channel.send(changedavatar)
       message.react('✅');
    } else { 
       message.channel.send(`> **:bulb: Usage**: ${prefix}settings [ \`setname\` - \`setavatar\` - ]`);
       message.react('ℹ️');
    }
  }
      //development By Sanad


      if (message.content === prefix + "ping") {
        const betha = new Discord.MessageEmbed()
        .setTitle('سرعتي')
        .setColor("#cea00d")
        .addField([`${Date.now() - message.createdTimestamp}` + " في الثانيه "])
        .setAuthor(message.author.username, message.author.avatarURL({ format: 'png', dynamic: true }))
      message.channel.send(betha)
      }
});


    //development By Sanad 


//development By Sanad

//token bot 
client.login(process.env.token).catch((err) => {
	console.warn("\033[31m Token Invalid")
})
